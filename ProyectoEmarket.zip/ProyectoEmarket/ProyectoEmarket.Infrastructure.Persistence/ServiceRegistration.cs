﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Infrastructure.Persistence.Contexts;
using ProyectoEmarket.Infrastructure.Persistence.Repositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Infrastructure.Persistence
{
    //Extension Method - Decorator
    public static class ServiceRegistration
    {

        public static void AddPersistenceInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            #region Context

            if (configuration.GetValue<bool>("UseInMemoryDatabase"))
            {
                services.AddDbContext<ApplicationContext>(options => options.UseInMemoryDatabase("ApplicationDb"));
            }
            else
            {
                services.AddDbContext<ApplicationContext>(options =>
                    options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"),
                     m => m.MigrationsAssembly(typeof(ApplicationContext).Assembly.FullName)));
            }
            #endregion
            #region Repositorios
            services.AddTransient(typeof(IGenericRepositorio<>), typeof(GenericRepositorio<>));
            services.AddTransient<IAnuncioRepositorio, AnuncioRepositorio>();
            services.AddTransient<ICategoryRepositorio, CategoryRepositorio>();
            services.AddTransient<IUserRepositorio, UserRepositorio>();
            #endregion

        }
    }
}
