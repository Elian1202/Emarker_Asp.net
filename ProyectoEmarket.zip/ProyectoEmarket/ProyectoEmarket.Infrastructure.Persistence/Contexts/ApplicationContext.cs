﻿using Microsoft.EntityFrameworkCore;
using ProyectoEmarket.Core.Domain.Common;
using ProyectoEmarket.Core.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProyectoEmarket.Infrastructure.Persistence.Contexts
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options) { }

        public DbSet<Anuncio> Anuncios { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<User> Users { get; set; }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            foreach(var entry in ChangeTracker.Entries<AuditableBaseEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.Created = DateTime.Now;
                        entry.Entity.CreatedBy = "DefaultAppUser";
                        break;

                    case EntityState.Modified:
                        entry.Entity.LastModified = DateTime.Now;
                        entry.Entity.LastModifiedBy = "DefaultAppUser";
                        break;
                }
            }
            return base.SaveChangesAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region "tables"

            modelBuilder.Entity<Anuncio>().ToTable("anuncios");
            modelBuilder.Entity<Category>().ToTable("Categorys");
            modelBuilder.Entity<User>().ToTable("Users");

            #endregion

            #region "Primary keys"
            modelBuilder.Entity<Anuncio>()
                .HasKey(Anuncio => Anuncio.Id);
            modelBuilder.Entity<Category>()
                .HasKey(Category => Category.Id);
            modelBuilder.Entity<User>()
                .HasKey(user => user.Id);
            #endregion

            #region "Relationships"
            modelBuilder.Entity<Category>().HasMany<Anuncio>(category => category.Anuncios)
                .WithOne(Anuncios => Anuncios.Category)
                .HasForeignKey(anuncios => anuncios.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>().HasMany<Anuncio>(user => user.Anuncio)
                .WithOne(Anuncio => Anuncio.User)
                .HasForeignKey(Anuncio => Anuncio.UserId)
                .OnDelete(DeleteBehavior.Cascade);
            #endregion

            #region "Property configurations"
            #region "Anuncio"
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.Name).IsRequired();
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.Precio).IsRequired();
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.ImageUrl).IsRequired();
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.ImageUrl2).IsRequired();
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.ImageUrl3).IsRequired();
            modelBuilder.Entity<Anuncio>().Property(anuncios => anuncios.Descripcion).IsRequired();
            #endregion

            #region"Category"
            modelBuilder.Entity<Category>()
                .Property(categories => categories.Name)
                .IsRequired().HasMaxLength(100);

            #endregion

            #region"users"
            modelBuilder.Entity<User>()
                .Property(user => user.Name)
                .IsRequired().HasMaxLength(150);
            modelBuilder.Entity<User>()
                .Property(user => user.Password)
                .IsRequired();
            modelBuilder.Entity<User>()
                .Property(user => user.UserName)
                .IsRequired().HasMaxLength(100);

            modelBuilder.Entity<User>()
                .Property(user => user.Email)
                .IsRequired();

            modelBuilder.Entity<User>()
                .Property(user => user.Phone)
                .IsRequired();
            #endregion

            #endregion

        }

    }
}
