﻿using Microsoft.EntityFrameworkCore;
using ProyectoEmarket.Core.Application.Helpers;
using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Core.Application.ViewModels.User;
using ProyectoEmarket.Core.Domain.Entities;
using ProyectoEmarket.Infrastructure.Persistence.Contexts;
using System.Threading.Tasks;

namespace ProyectoEmarket.Infrastructure.Persistence.Repositorios
{
    public class UserRepositorio : GenericRepositorio<User>, IUserRepositorio
    {
        private readonly ApplicationContext _dbContex;

        public UserRepositorio(ApplicationContext dbContex) : base(dbContex)
        {
            _dbContex = dbContex;
        }

        public override async Task AddAsync(User entity)
        {
            entity.Password = PasswordEncryption.ComputeSha256Has(entity.Password);
            await base.AddAsync(entity);    
        }

        public async Task<User> LoginAsync(LoginViewModel loginVm)
        {
            string passwordEncrypy = PasswordEncryption.ComputeSha256Has(loginVm.Password);
            User user = await _dbContex.Set<User>()
                .FirstOrDefaultAsync(user => user.UserName == loginVm.UserName && user.Password == passwordEncrypy);
            return user;
        }

    }
}
