﻿using Microsoft.EntityFrameworkCore;
using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Core.Domain.Entities;
using ProyectoEmarket.Infrastructure.Persistence.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Infrastructure.Persistence.Repositorios
{
    public class CategoryRepositorio : GenericRepositorio<Category>, ICategoryRepositorio
    {
        private readonly ApplicationContext _dbContex;

        public CategoryRepositorio(ApplicationContext dbContex) : base(dbContex)
        {
            _dbContex = dbContex;
        }
       
    }
}
