﻿using Microsoft.EntityFrameworkCore;
using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Infrastructure.Persistence.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Infrastructure.Persistence.Repositorios
{
    public class GenericRepositorio<Entity> :IGenericRepositorio<Entity> where Entity : class
    {
        private readonly ApplicationContext _dbContex;

        public GenericRepositorio(ApplicationContext dbContex)
        {
            _dbContex = dbContex;
        }
        public virtual async  Task AddAsync(Entity entity)
        {
            await _dbContex.Set<Entity>().AddAsync(entity);
            await _dbContex.SaveChangesAsync();
        }

        public virtual async Task UpdateAsync(Entity entity)
        {
            _dbContex.Entry(entity).State = EntityState.Modified;
            await _dbContex.SaveChangesAsync();
        }

        public virtual async Task DeleteAsync(Entity entity)
        {
            _dbContex.Set<Entity>().Remove(entity);
            await _dbContex.SaveChangesAsync();
        }

        public virtual async Task<List<Entity>> GetAllAsync()
        {
            return await _dbContex.Set<Entity>().ToListAsync();
        }

        public virtual async Task<List<Entity>> GetAllwhitIncludeAsync(List<string> properties)
        {
            var query = _dbContex.Set<Entity>().AsQueryable();
            foreach (string property in properties)
            {
                query = query.Include(property);
            }
            return await query.ToListAsync();
        }

        public virtual async Task<Entity> GetByIdAsync(int id)
        {
            return await _dbContex.Set<Entity>().FindAsync(id);
        }
    }
}
