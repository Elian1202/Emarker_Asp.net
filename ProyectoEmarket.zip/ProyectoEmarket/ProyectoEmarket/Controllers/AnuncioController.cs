﻿using Microsoft.AspNetCore.Mvc;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels;
using ProyectoEmarket.Core.Application.ViewModels.Anuncios;
using System.Threading.Tasks;

namespace ProyectoEmarket.Controllers
{
    public class AnuncioController : Controller
    {
        private readonly IAnuncioService _anuncioService;
        private readonly ICategoryService _categoryService;
        public AnuncioController(IAnuncioService anuncioService, ICategoryService categoryService)
        {
            _anuncioService = anuncioService;
            _categoryService = categoryService;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _anuncioService.GeyAllViewModel());
        }

        public async Task<IActionResult> Create()
        {
            SaveAnuncioViewModel vm = new();
            vm.categories = await _categoryService.GeyAllViewModel();
            return View("SaveAnuncio", vm);
        }

        [HttpPost]
        public async Task<IActionResult> Create(SaveAnuncioViewModel vm)
        {
            
            if (!ModelState.IsValid)
            {
                vm.categories = await _categoryService.GeyAllViewModel();
                return View("SaveAnuncio", vm);
            }
            await _anuncioService.Add(vm);
            return RedirectToRoute(new { controller = "Anuncio", action = "Index" });
            
        }
        public async Task<IActionResult> Edit(int id)
        {

            SaveAnuncioViewModel vm = await _anuncioService.GetByIdSaveViewModel(id);
            vm.categories = await _categoryService.GeyAllViewModel();
            return View("SaveAnuncio", vm);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(SaveAnuncioViewModel vm)
        {

            if (!ModelState.IsValid)
            {
                vm.categories = await _categoryService.GeyAllViewModel();
                return View("SaveAnuncio", vm);
            }

            await _anuncioService.Update(vm);
            return RedirectToRoute(new { controller = "Anuncio", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {

           
            return View(await _anuncioService.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
        
            await _anuncioService.Delete(id);
            return RedirectToRoute(new { controller = "Anuncio", action = "Index" });
        }


    }
}
