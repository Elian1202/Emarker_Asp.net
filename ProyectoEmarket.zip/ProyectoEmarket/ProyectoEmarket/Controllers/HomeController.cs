﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.Anuncios;
using ProyectoEmarket.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ProyectoEmarket.Controllers
{
    public class HomeController : Controller
    {
        private readonly IAnuncioService _anuncioService;
        private readonly ICategoryService _categoryService;

        public HomeController(IAnuncioService anuncioService, ICategoryService categoryService)
        {
            _anuncioService = anuncioService;
            _categoryService = categoryService;
        }

        public async Task<IActionResult> Index(FilterAnuncioViewModel vm)
        {
            ViewBag.Categories = await _categoryService.GeyAllViewModel();
            return View(await _anuncioService.GeyAllViewModelwhitFiltros(vm));
        }
    }
}
