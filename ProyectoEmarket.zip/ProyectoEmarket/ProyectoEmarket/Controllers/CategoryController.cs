﻿using Microsoft.AspNetCore.Mvc;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.Categories;
using System.Threading.Tasks;

namespace ProyectoEmarket.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICategoryService _categoryService;
        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _categoryService.GeyAllViewModel());
        }

        public IActionResult Create()
        {
            //SaveAnuncioViewModel vm = new();
            //vm.TiposLis = await _tiposService.GeyAllViewModel();
            //vm.RegionLis = await _regionesService.GeyAllViewModel();
            return View("SaveCategory", new SaveCategoryViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Create(SaveCategoryViewModel vm)
        {
            //SaveAnuncioViewModel vm = new();
            //vm.TiposLis = await _tiposService.GeyAllViewModel();
            //vm.RegionLis = await _regionesService.GeyAllViewModel();
            if (!ModelState.IsValid)
            {
                return View("SaveCategory", vm);
            }
            await _categoryService.Add(vm);
            return RedirectToRoute(new { controller = "Category", action = "Index" });
            //return View("SaveAnuncio", new SaveAnuncioViewModel());
        }
        public async Task<IActionResult> Edit(int id)
        {

            //SavePokemonViewModel vm = await _pokemonService.GetByIdSavePokemonViewModel(id);
            //vm.RegionLis = await _regionesService.GeyAllViewModel();
            //vm.TiposLis = await _tiposService.GeyAllViewModel();
            //return View("SavePokemon", vm);
            return View("SaveCategory", await _categoryService.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(SaveCategoryViewModel vm)
        {
            //if (!ModelState.IsValid)
            //{
            //    vm.RegionLis = await _regionesService.GeyAllViewModel();
            //    vm.TiposLis = await _tiposService.GeyAllViewModel();
            //    return View("SavePokemon", vm);
            //}

            if (!ModelState.IsValid)
            {
                return View("SaveCategory", vm);
            }

            await _categoryService.Update(vm);
            return RedirectToRoute(new { controller = "Category", action = "Index" });
        }

        public async Task<IActionResult> Delete(int id)
        {

            //SavePokemonViewModel vm = await _pokemonService.GetByIdSavePokemonViewModel(id);
            //vm.RegionLis = await _regionesService.GeyAllViewModel();
            //vm.TiposLis = await _tiposService.GeyAllViewModel();
            //return View("SavePokemon", vm);
            return View(await _categoryService.GetByIdSaveViewModel(id));
        }

        [HttpPost]
        public async Task<IActionResult> DeletePost(int id)
        {
            //if (!ModelState.IsValid)
            //{
            //    vm.RegionLis = await _regionesService.GeyAllViewModel();
            //    vm.TiposLis = await _tiposService.GeyAllViewModel();
            //    return View("SavePokemon", vm);
            //}
            await _categoryService.Delete(id);
            return RedirectToRoute(new { controller = "Category", action = "Index" });
        }


    }
}
