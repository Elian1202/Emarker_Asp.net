﻿using Microsoft.AspNetCore.Mvc;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.User;
using System.Threading.Tasks;

namespace ProyectoEmarket.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginViewModel loginVm)
        {
            if (!ModelState.IsValid)
            {
               
                return View(loginVm);
            }
            UserViewModel userVm = await _userService.Login(loginVm);

            if (userVm != null)
            {
                return RedirectToRoute(new { controller = "Home", action = "Index" });
            }
            else
            {
                ModelState.AddModelError("userValidation", "Datos de acceso incorrecto");
            }
            return View(loginVm);
        }

        public IActionResult Register()
        {
            return View(new SaveUserViewModel());
        }

        [HttpPost]
        public async Task<IActionResult>  Register(SaveUserViewModel Uservm)
        {
            if (!ModelState.IsValid)
            {

                return View(Uservm);
            }
            await _userService.Add(Uservm);
            return RedirectToRoute(new { controller = "User", action = "Index" });
        }



    }
}
