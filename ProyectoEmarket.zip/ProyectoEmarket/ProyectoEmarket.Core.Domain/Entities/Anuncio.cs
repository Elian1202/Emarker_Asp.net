﻿using ProyectoEmarket.Core.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Domain.Entities
{
    public class Anuncio : AuditableBaseEntity
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public string ImageUrl { get; set; }

        public string ImageUrl2 { get; set; }
        public string ImageUrl3 { get; set; }

        public double Precio { get; set; }


        public int CategoryId { get; set; }
        //public int UsuarioId { get; set; }
        //navigation property
        public Category Category { get; set; }
        //public Usuario Usuario { get; set; }

        public int UserId { get; set; }
        //public int UsuarioId { get; set; }
        //navigation property
        public User User { get; set; }
        //public Usuario Usuario { get; set; }
    }
}
