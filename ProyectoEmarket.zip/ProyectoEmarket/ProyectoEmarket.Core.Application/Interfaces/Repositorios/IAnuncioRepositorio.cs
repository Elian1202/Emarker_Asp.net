﻿using ProyectoEmarket.Core.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Interfaces.Repositorios
{
    public interface IAnuncioRepositorio : IGenericRepositorio<Anuncio>
    {
       
    }
}
