﻿using ProyectoEmarket.Core.Application.ViewModels.Anuncios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Interfaces.Services
{
    public interface IAnuncioService : IGenericService<SaveAnuncioViewModel, AnuncioViewModel>
    {
        Task<List<AnuncioViewModel>> GeyAllViewModelwhitFiltros(FilterAnuncioViewModel filter);

    }
}
