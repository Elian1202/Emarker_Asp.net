﻿using ProyectoEmarket.Core.Application.ViewModels.Categories;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.ViewModels.User
{
    public class SaveUserViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Debe Colocar el nombre del Usuario")]
        [DataType(DataType.Text)]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Debe Colocar una Contraseña")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Compare(nameof(Password), ErrorMessage = "Las Contraseñas no coinciden")]
        [Required(ErrorMessage = "Debe Colocar una Contraseña")]
        [DataType(DataType.Password)]
        public string ConfirPassword { get; set; }

        [Required(ErrorMessage = "Debe Colocar el Nombre")]
        [DataType(DataType.Text)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Debe Colocar un Correo Electronico")]
        [DataType(DataType.Text)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Debe Colocar el Telefono")]
        [DataType(DataType.Text)]
        public string Phone { get; set; }}

        
}
        