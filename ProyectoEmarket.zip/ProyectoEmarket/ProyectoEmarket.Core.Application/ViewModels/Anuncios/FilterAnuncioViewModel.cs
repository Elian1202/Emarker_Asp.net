﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.ViewModels.Anuncios
{
    public class FilterAnuncioViewModel
    {
        public int? CategoryId { get; set; }

        public string AnuncioName { get; set; }
    }
}
