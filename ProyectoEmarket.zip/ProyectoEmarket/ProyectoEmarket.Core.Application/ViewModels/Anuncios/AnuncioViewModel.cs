﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.ViewModels.Anuncios
{
    public class AnuncioViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public string ImageUrl { get; set; }
        public string ImageUrl2 { get; set; }
        public string ImageUrl3 { get; set; }

        public double Precio { get; set; }

        public int CategoryId { get; set; }

        public string CategoryName { get; set; }

        public string AnuncioName { get; set; }



    }
}
