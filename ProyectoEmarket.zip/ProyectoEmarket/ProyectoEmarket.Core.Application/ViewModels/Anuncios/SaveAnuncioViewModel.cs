﻿using ProyectoEmarket.Core.Application.ViewModels.Categories;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.ViewModels.Anuncios
{
    public class SaveAnuncioViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Debe Colocar el nombre del anuncio")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Debe Colocar la descripcion del anuncio")]
        public string Descripcion { get; set; }
        [Required(ErrorMessage = "Debe Colocar la imagen")]
        public string ImageUrl { get; set; }
        [Required(ErrorMessage = "Debe Colocar la imagen 2")]
        public string ImageUrl2 { get; set; }
        [Required(ErrorMessage = "Debe Colocar la imagen 3")]
        public string ImageUrl3 { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Debe Colocar el Precio")]
        public double Precio { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Debe Colocar La categoria")]
        public int CategoryId { get; set; }

        public List<CategoryViewModel> categories { get; set; }
    }
}
