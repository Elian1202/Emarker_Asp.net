﻿using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.User;
using ProyectoEmarket.Core.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepositorio _UserRepositorio;

        public UserService(IUserRepositorio userRepositorio )
        {
            _UserRepositorio = userRepositorio;
        }

        public async Task Update(SaveUserViewModel vm)
        {
            User user = new();
            user.Id = vm.Id;
            user.Name = vm.Name;
            user.UserName = vm.UserName;
            user.Email = vm.Email;
            user.Password = vm.Password;
            user.Phone = vm.Phone;
            await _UserRepositorio.UpdateAsync(user);
        }

        public async Task<UserViewModel> Login(LoginViewModel loginvm)
        {
            User user = await _UserRepositorio.LoginAsync(loginvm);
            if(user == null)
            {
                return null;
            }

            UserViewModel userVm  = new();
            userVm.Id = userVm.Id;
            userVm.Name = userVm.Name;
            userVm.UserName = userVm.UserName;
            userVm.Email = userVm.Email;
            userVm.Password = userVm.Password;
            userVm.Phone = userVm.Phone;
            await _UserRepositorio.UpdateAsync(user);

            return userVm;
        }

        public async Task Add(SaveUserViewModel vm)
        {
            User user = new();
            user.Id = vm.Id;
            user.Name = vm.Name;
            user.UserName = vm.UserName;
            user.Email = vm.Email;
            user.Password = vm.Password;
            user.Phone = vm.Phone;
            await _UserRepositorio.AddAsync(user);
        }

        public async Task Delete(int id)
        {
            var user = await _UserRepositorio.GetByIdAsync(id);
            await _UserRepositorio.DeleteAsync(user);
        }

        public async Task<SaveUserViewModel> GetByIdSaveViewModel(int id)
        {
            var user = await _UserRepositorio.GetByIdAsync(id);

            SaveUserViewModel vm = new();
            vm.Id = user.Id;
            vm.Name = user.Name;
            vm.UserName = user.UserName;
            vm.Email = user.Email;
            vm.Password = user.Password;
            vm.Phone = user.Phone;
            

            return vm;
        }

        public async Task<List<UserViewModel>> GeyAllViewModel()
        {
            var userList = await _UserRepositorio.GetAllwhitIncludeAsync(new List<string> { "Category" });
            return userList.Select(User => new UserViewModel
            {
                Name = User.Name,
                UserName = User.UserName,
                Id = User.Id,
                Password = User.Password,
                Email = User.Email,
                Phone = User.Phone,
            }).ToList();
        }
       


    }
}

