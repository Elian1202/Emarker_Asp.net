﻿using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.Anuncios;
using ProyectoEmarket.Core.Application.ViewModels.Categories;
using ProyectoEmarket.Core.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepositorio _categoryRepositorio;

        public CategoryService(ICategoryRepositorio categoryRepositorio)
        {
            _categoryRepositorio = categoryRepositorio;
        }

        public async Task Update(SaveCategoryViewModel vm)
        {
            Category category = new();
            category.Id = vm.Id;
            category.Name = vm.Name;
            category.Descripcion = vm.Descripcion;
            await _categoryRepositorio.UpdateAsync(category);
        }

        public async Task Add(SaveCategoryViewModel vm)
        {
            Category category = new();
            category.Name = vm.Name;
            category.Descripcion = vm.Descripcion;
            await _categoryRepositorio.AddAsync(category);
        }

        public async Task Delete(int id)
        {
            var category = await _categoryRepositorio.GetByIdAsync(id);
            await _categoryRepositorio.DeleteAsync(category);
        }

        public async Task<SaveCategoryViewModel> GetByIdSaveViewModel(int id)
        {
            var category = await _categoryRepositorio.GetByIdAsync(id);

            SaveCategoryViewModel vm = new();
            vm.Id = category.Id;
            vm.Name = category.Name;
            vm.Descripcion = category.Descripcion;
            
            return vm;
        }

        public async Task<List<CategoryViewModel>> GeyAllViewModel()
        {
            var categoryList = await _categoryRepositorio.GetAllwhitIncludeAsync(new List<string> {"Anuncios"});
            return categoryList.Select(Category => new CategoryViewModel
            {
                Name = Category.Name,
                Descripcion = Category.Descripcion,
                Id = Category.Id,
                AnunciosQuantity = Category.Anuncios.Count()

            }).ToList();
        }
        //public async Task<List<PokemonViewModel>> GeyAllViewModelwhitFiltros(FiltroPokemon filter)
        //{
        //    var pokemonList = await _pokemonRepositorio.GetAllwhitIncludeAsync();
        //    var ListViewModels = pokemonList.Select(Pokemon => new PokemonViewModel
        //    {
        //        Name = Pokemon.Name,
        //        Descripcion = Pokemon.Descripcion,
        //        Id = Pokemon.Id,
        //        ImageUrl = Pokemon.ImageUrl,
        //        RegionName = Pokemon.regiones.Name,
        //        TipoPrimarioName = Pokemon.tipos.Name,
        //        TipoSecundarioName = Pokemon.tipos2.Name,
        //        TiposId = Pokemon.tipos2.Id,
        //        RegionesId = Pokemon.regiones.Id,
        //    }).ToList();

        //    if (filter.TiposId != null)
        //    {
        //        ListViewModels = ListViewModels.Where(pokemon => pokemon.TiposId == filter.TiposId.Value).ToList();
        //    }
        //    if (filter.RegionesId != null)
        //    {
        //        ListViewModels = ListViewModels.Where(pokemon => pokemon.RegionesId == filter.RegionesId.Value).ToList();
        //    }

        //    return ListViewModels;
        //}
    }
    

    }

