﻿using ProyectoEmarket.Core.Application.Interfaces.Repositorios;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.ViewModels.Anuncios;
using ProyectoEmarket.Core.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Services
{
    public class AnuncioService : IAnuncioService
    {
        private readonly IAnuncioRepositorio _anuncioRepositorio;

        public AnuncioService(IAnuncioRepositorio anuncioRepositorio)
        {
            _anuncioRepositorio = anuncioRepositorio;
        }

        public async Task Update(SaveAnuncioViewModel vm)
        {
            Anuncio anuncio = new();
            anuncio.Id = vm.Id;
            anuncio.Name = vm.Name;
            anuncio.Descripcion = vm.Descripcion;
            anuncio.ImageUrl = vm.ImageUrl;
            anuncio.ImageUrl2 = vm.ImageUrl2;
            anuncio.ImageUrl3 = vm.ImageUrl3;
            anuncio.Precio = vm.Precio;
            anuncio.CategoryId = vm.CategoryId;
            await _anuncioRepositorio.UpdateAsync(anuncio);
        }

        public async Task Add(SaveAnuncioViewModel vm)
        {
            Anuncio anuncio = new();
            anuncio.Name = vm.Name;
            anuncio.Descripcion = vm.Descripcion;
            anuncio.ImageUrl = vm.ImageUrl;
            anuncio.ImageUrl2 = vm.ImageUrl2;
            anuncio.ImageUrl3 = vm.ImageUrl3;
            anuncio.Precio = vm.Precio;
            anuncio.CategoryId = vm.CategoryId;
            await _anuncioRepositorio.AddAsync(anuncio);
        }

        public async Task Delete(int id)
        {
            var anuncio = await _anuncioRepositorio.GetByIdAsync(id);
            await _anuncioRepositorio.DeleteAsync(anuncio);
        }

        public async Task<SaveAnuncioViewModel> GetByIdSaveViewModel(int id)
        {
            var anuncio = await _anuncioRepositorio.GetByIdAsync(id);

            SaveAnuncioViewModel vm = new();
            vm.Id = anuncio.Id;
            vm.Name = anuncio.Name;
            vm.Descripcion = anuncio.Descripcion;
            vm.ImageUrl = anuncio.ImageUrl;
            vm.ImageUrl2 = anuncio.ImageUrl2;
            vm.ImageUrl3 = anuncio.ImageUrl3;
            vm.Precio = anuncio.Precio;

            return vm;
        }

        public async Task<List<AnuncioViewModel>> GeyAllViewModel()
        {
            var anuncioList = await _anuncioRepositorio.GetAllwhitIncludeAsync(new List<string> { "Category" });
            return anuncioList.Select(Anuncio => new AnuncioViewModel
            {
                Name = Anuncio.Name,
                Descripcion = Anuncio.Descripcion,
                Id = Anuncio.Id,
                ImageUrl = Anuncio.ImageUrl,
                ImageUrl2 = Anuncio.ImageUrl2,
                ImageUrl3 = Anuncio.ImageUrl3,
                Precio = Anuncio.Precio,
                CategoryName = Anuncio.Category.Name

            }).ToList();
        }
        public async Task<List<AnuncioViewModel>> GeyAllViewModelwhitFiltros(FilterAnuncioViewModel filter)
        {
            var anuncioList = await _anuncioRepositorio.GetAllwhitIncludeAsync(new List<string> { "Category" });
            var ListViewModels = anuncioList.Select(Anuncio => new AnuncioViewModel
            {
                Name = Anuncio.Name,
                Descripcion = Anuncio.Descripcion,
                Id = Anuncio.Id,
                ImageUrl = Anuncio.ImageUrl,
                ImageUrl2 = Anuncio.ImageUrl2,
                ImageUrl3 = Anuncio.ImageUrl3,
                CategoryName = Anuncio.Category.Name,
                Precio = Anuncio.Precio,
                CategoryId = Anuncio.CategoryId,
                AnuncioName = Anuncio.Name,

            }).ToList();

            if (filter.CategoryId != null)
            {
                ListViewModels = ListViewModels.Where(anuncio => anuncio.CategoryId == filter.CategoryId.Value).ToList();
            }
            if (filter.AnuncioName!= null)
            {
                ListViewModels = ListViewModels.Where(anuncio => anuncio.AnuncioName == filter.AnuncioName).ToList();
            }

            return ListViewModels;

        }


    }
}

