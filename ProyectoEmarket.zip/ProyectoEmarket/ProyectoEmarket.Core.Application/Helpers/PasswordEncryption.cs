﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEmarket.Core.Application.Helpers
{
    public class PasswordEncryption
    {
        public static string ComputeSha256Has(string password)
        {
            //Create a SHA256
            using (SHA256 sha256Has = SHA256.Create())
            {
                byte[] bytes = sha256Has.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }

            //Convert byte array to a string
            
            
                
        }
    }
}
