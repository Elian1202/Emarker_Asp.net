﻿using Microsoft.Extensions.DependencyInjection;
using ProyectoEmarket.Core.Application.Interfaces.Services;
using ProyectoEmarket.Core.Application.Services;


namespace ProyectoEmarket.Core.Application
{
    public static class ServiceRegistration
    {



        public static void AddApplicationLayer(this IServiceCollection services)
        {

            #region Services
            services.AddTransient<IAnuncioService, AnuncioService>();
            services.AddTransient<ICategoryService, CategoryService>();
            services.AddTransient<IUserService, UserService>();
            #endregion

        }
    }
}
